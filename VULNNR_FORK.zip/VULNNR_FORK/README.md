
<p align="middle"><img src='https://imgur.com/iMi5P6g.png'> </img></center>

## About

<p align="middle"><p>
  Vulnnr is a Vulnerability Scanner & Auto Exploiter You can use this tool to pentest the security of your website 
</p>


<hr>


## Install
```json
git clone https://github.com/X-x-X-0/Vulnnr.git
pip3 install -r requirements.txt
python3 Vulnnr.py
```

## Credits
```json
Nano - Creator
VulnX Github - CMS detector
```

## Discontinued
* after long thought, the project will stop updating. i will create better pentesting tools in the future.
* i put alot of hardwork in the project but i wanna strive to do better.
